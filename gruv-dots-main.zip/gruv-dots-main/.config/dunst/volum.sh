#!/bin/bash

function light_get {
    a=${xbacklight}
    return $a
}

light_get