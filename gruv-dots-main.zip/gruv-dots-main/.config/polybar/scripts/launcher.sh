rofi -modi drun -show
