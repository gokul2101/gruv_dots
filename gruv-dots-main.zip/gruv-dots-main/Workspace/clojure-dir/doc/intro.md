# Introduction to clojure-dir

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
