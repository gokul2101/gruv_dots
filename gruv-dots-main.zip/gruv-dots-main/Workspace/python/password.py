from string import ascii_letters as letters, digits, punctuation
from random import choice

STRENGTH = 20

# concatenate(add) all characters
choices = letters + digits + punctuation

# Choose random characters from all char choices
random_chars = [choice(choices) for _ in range(STRENGTH)]

# Convert those random list to string
password = "".join(random_chars)

# Print the password
print(password)

# OUTPUT
>> SY13BpZDrxf(@1qMl2t$