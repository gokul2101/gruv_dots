#!/bin/bash

echo "Enter text "
read -r a
echo "Enter search word"
read -r b
strindex() { 
  x="${1%%$2*}"
  [[ "$x" = "$1" ]] && echo -1 || echo "${#x}"
}
strindex "$a" "$b"