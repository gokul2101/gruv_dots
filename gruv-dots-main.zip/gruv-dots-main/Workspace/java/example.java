public class example {
    public static void main(String[] args) {
        char[] s = "a11".toCharArray();
        String alpha = "";
        String in = "";
        for(char ch : s) {
            if(Character.isAlphabetic(ch)){
                alpha+=ch;
            }else{
                in+=ch;
            }
        }
        System.out.println(alpha);
        System.out.println(in);
    }
}
