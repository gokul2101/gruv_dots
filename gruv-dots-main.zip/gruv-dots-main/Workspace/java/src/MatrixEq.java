import java.util.Scanner;

public class MatrixEq {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] ar = sc.nextLine().split(" ");
		
		int row = Integer.parseInt(ar[0]);
		int column = Integer.parseInt(ar[1]);
		String arr[][] = new String[row][column];
		
		for(int i=0;i<row;i++) {
			String[] inp = sc.nextLine().split(" ");
			arr[i] = inp;
		}

		for(int i=1;i<row-1;i++) {
			for(int j=0;j<column;j++) {
				if(arr[i][j].equals("+")) {
					int a = Integer.parseInt(arr[i-1][j]);
					int b = Integer.parseInt(arr[i+1][j]);
					arr[i][j] = String.valueOf(a+b);
				} else if(arr[i][j].equals("-")) {
					int a = Integer.parseInt(arr[i-1][j]);
					int b = Integer.parseInt(arr[i+1][j]);
					arr[i][j] = String.valueOf(Math.abs(a-b));
				}
			}
		}
		
		for(String i[] : arr) {
			for(String j:i) {
				System.out.print(j+" ");
			}
			System.out.println();
		}

        sc.close();
	}
}