public class Hello {
	public static void main(String[] args) {
		String s = "-2.46".trim();
		try {
			Integer.parseInt(s);
			System.out.println(true);;
		} catch(NumberFormatException e){
			System.out.println(false);;
		}
	}
}