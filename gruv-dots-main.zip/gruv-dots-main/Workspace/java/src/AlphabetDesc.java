import java.util.*;

public class AlphabetDesc {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        HashMap<Character, Integer> hm = new HashMap<>();
        char[] arr = sc.nextLine().toCharArray();
        for (char ch : arr) {
            if (hm.containsKey(ch)) {
                continue;
            } else {
                hm.put(ch, 1);
            }
        }
        StringBuilder str = new StringBuilder();
        for (int i = 122; i >= 97; i--) {
            if (hm.containsKey((char) i)) {
                str.append((char) i);
            }
        }
        System.out.println(str.toString());
        sc.close();
    }
}