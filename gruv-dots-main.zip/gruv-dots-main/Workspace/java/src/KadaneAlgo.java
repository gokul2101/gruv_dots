public class KadaneAlgo {
    public static void main(String[] args) {
        // Kadane Algorith to find max sum substring
    }
}
