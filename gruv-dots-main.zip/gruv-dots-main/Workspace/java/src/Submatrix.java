import java.util.*;

public class Submatrix {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String[] in = sc.nextLine().split(" ");
		int row = Integer.parseInt(in[0]);
		int column = Integer.parseInt(in[1]);
		int wrong = 0;
		String arr[][] = new String[row][column];
		for(int i=0;i<row;i++) {
			arr[i] = sc.nextLine().split(" ");
		}
		for(int i=1;i<=row;i++) {
			for(int j=1;j<=column;j++) {
				if(i%2!=0 && j%2!=0) {
					if(!arr[i-1][j-1].equals("A")){
						wrong++;
					}
				} else if(i%2==0 && j%2!=0) {
					if(!arr[i-1][j-1].equals("C")){
						wrong++;
					}
				} else if(i%2!=0 && j%2==0) {
					if(!arr[i-1][j-1].equals("B")){
						wrong++;
					}
				} else if(i%2==0 && j%2==0) {
					if(!arr[i-1][j-1].equals("D")){
						wrong++;
					}
				}
			}
		}
		System.out.println(wrong);
		sc.close();
	}
}