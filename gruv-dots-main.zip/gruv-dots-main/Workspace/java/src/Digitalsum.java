import java.util.*;

public class Digitalsum {
	public static void digitalSum(String str) {
		int ans = 0;
		for(int i=0;i<str.length();i++) {
			ans += Integer.parseInt(String.valueOf(str.charAt(i)));
		}
		String res = String.valueOf(ans);
		if(res.length()>1) {
			digitalSum(res);
		} else {
			System.out.println(ans);
		}
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String str = sc.nextLine();
		digitalSum(str);
		sc.close();
	}
}