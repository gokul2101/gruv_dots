import java.util.*;

public class Diagonalsum {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        sc.nextLine();
        int i=0;
        int j=n-1;
        int rd = 0,ld = 0;
        while(n>0) {
            String[] arr = sc.nextLine().split(" ");
            ld += Integer.parseInt(arr[i]);
            rd += Integer.parseInt(arr[j]);
            i++;
            j--;
            n--;
        }
        System.out.println(rd);
        System.out.println(ld);
        System.out.println(Math.abs(rd+ld));
        sc.close();
    }
}