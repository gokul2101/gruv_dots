import java.util.*;

class Diagonalwords {
	public static void main(String[] args)
	{
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        int len = str.length();

        for(int i=0;i<len;i++) {
            int g = len-i-1;
            for(int j=0;j<len;j++) {
                if(i==j) {
                    System.out.print(str.charAt(j));
                } else if(j==g) {
                    System.out.print(str.charAt(j));
                } else {
                    System.out.print(" ");
                }
            }
            System.out.println();
            sc.close();
        }
    }
}
