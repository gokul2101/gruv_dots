# Collection Notes

### Differences Between Collections :

| Names                 | Ordering | Random Access | KeyValue | Duplicate | Null | Thread Safety |
| --------------------- | -------- | ------------- | -------- | --------- | ---- | ------------- |
| ArrayList             | yes      | yes           | -        | yes       | yes  | -             |
| LinkedList            | yes      | -             | -        | yes       | yes  | -             |
| Hashset               | -        | -             | -        | -         | yes  | -             |
| TreeSet               | yes      | -             | -        | -         | -    | -             |
| HashMap               | -        | yes           | yes      | -         | yes  | -             |
| TreeMap               | yes      | yes           | yes      | -         | -    | -             |
| Vector                | yes      | yes           | -        | yes       | yes  | yes           |
| HashTable             | -        | yes           | yes      | -         | -    | yes           |
| Stack                 | yes      | -             | -        | yes       | yes  | yes           |
| CopyOnWrite ArrayList | yes      | yes           | -        | yes       | yes  | yes           |
| Concurrent HashMap    | -        | yes           | yes      | -         | -    | yes           |


