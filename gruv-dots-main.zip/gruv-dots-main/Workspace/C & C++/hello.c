#include<stdio.h>

int add(int *x){
    x = 1;
}

int main(){
    int x = 10;
    add(*x);
    printf("%d\n",x);
}
