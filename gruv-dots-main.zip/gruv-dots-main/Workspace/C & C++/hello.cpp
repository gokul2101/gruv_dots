#include<iostream>
using namespace std;

void add(int x,int y){
    cout<<x+y<<endl;
}

void add(char s,int x){
    cout<<s<<endl;
}

int main(){
    add(1,2);
    add('a',0);
    return 0;
}